import java.util.Random;
import java.util.Scanner;

public class XingzhouGame {

	public static void main(String[] args) {
		
		int[][] array = new int[10][10];

		for (int a = 0; a < array.length; a++) {
			for (int b = 0; b < array[0].length; b++) {
				array[a][b] = -1;
			}
		}

		int numRows = new Random().nextInt((9 - 0) + 1) + 0;
		int numCols = new Random().nextInt((9 - 0) + 1) + 0;
		char item = '*';
		array[numRows][numCols] = item;
		print(array);

		int answer = 0;

		while (answer < 4) {

			Scanner in = new Scanner(System.in);

			System.out.print("Show your coordinate (x,y): ");
			String inp = in.next();

			String rec[] = inp.split(",");

			while (true) {
				if (rec.length == 2) {
					int c = Integer.parseInt(rec[0]);
					int r = Integer.parseInt(rec[1]);

					if (c > 0 && c <= 10 && r > 0 && r <= 10) {

						if (array[r - 1][c - 1] == (int) item) {

							System.out.println("You win!");
							System.exit(0);
						}

						else if (array[r - 1][c - 1] == -1) {

							array[r - 1][c - 1] = calcDistance((numRows + 1), (numCols + 1), r, c);
							break;
						} else
							System.out.println("This move is already placed");
					} else
						System.out.println("Values are out of bound.");
				}

				System.out.print("Enter valid move (x,y): ");
				inp = in.next();
				rec = inp.split(",");
			}

			print(array);
			answer++;
		}

		System.out.println("You failed!");
		System.out.println("Item was at: (" + (numCols + 1) + "," + (numRows + 1) + ")");
	}

	public static void print(int[][] grid) {
		char item = '*';
		System.out.println("     1   2   3   4   5   6   7   8   9   10");
		for (int a = 0; a < grid.length; a++) {
			if (a != 9) {
				System.out.format("   -----------------------------------------\n" + (a + 1) + "  ");
			} else {
				System.out.format("   -----------------------------------------\n" + (a + 1) + " ");
			}
			for (int b = 0; b < grid[0].length; b++) {
				if (grid[a][b] != (int) item && grid[a][b] != -1) {

					System.out.print("| " + grid[a][b] + " ");
				} else

					System.out.print("|" + "   ");
			}
			System.out.print("|");
			System.out.println("");
		}
		System.out.format("   -----------------------------------------\n");
	}

	public static int calcDistance(int x1, int y1, int x2, int y2) {
		int distance = (int) Math.sqrt(Math.pow((x1 - x2), 2) + Math.pow((y1 - y2), 2));
		return distance;
	}
}
